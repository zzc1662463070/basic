<?php
namespace app\admin\controller;
use app\admin\model\Record;
use app\admin\controller\AdminAuth;
use ReCaptcha\RequestMethod\Post;
use think\Db;
use think\Validate;
use think\Image;
use think\Request;

class RecordController extends AdminAuth
 {
    public function index()
    {
        $data = array(
            'module_name' => '广告',
            'module_url' => SITE_URL . '/admin/record/',
            'module_slug' => 'record',
            'upload_path' => UPLOAD_PATH,
            'upload_url' => '/public/uploads/',
        );
        $recData = Db::table('record')->order('time desc')
            ->paginate(10);
        $this->assign('data', $data);
        $this->assign('page', $recData->render());
        $this->assign('list', $recData);
        return view();
    }

    public function searchRecord()
    {
        $data = array(
            'module_name' => '广告',
            'module_url' => SITE_URL . '/admin/record/',
            'module_slug' => 'record',
            'upload_path' => UPLOAD_PATH,
            'upload_url' => '/public/uploads/',
        );
        $g_id = Request::instance()->get('g_id');
        //起始时间
        $start_time = strtotime(Request::instance()->get('start_time'));
        //结束时间
        $end_time = strtotime(Request::instance()->get('end_time'));
        if (!empty($g_id)) {


            $g_Data = Db::table('guanggao')->where('g_id', $g_id)->select();
            if (!empty($g_Data)) {
                //点击总次数
                $result_show = Db::table('record')
                    ->where("time >= $start_time AND time <=$end_time")
                    ->where('type = 1')
                    ->where("g_id = $g_id")
                    ->count("num");
                $recData_show = Db::table('record')
                    ->where("time >= $start_time AND time <= $end_time")
                    ->where('type = 1')
                    ->where("g_id = $g_id")
                    ->find();
                $recData_show['num'] = $result_show;
                //展示总次数
                $result_clik = Db::table('record')
                    ->where("time > $start_time AND time < $end_time")
                    ->where('type = 2')
                    ->where("g_id = $g_id")
                    ->count("num");
                $list[0] = $recData_show;
                if ($result_clik) {
                    $recData_clik = Db::table('record')
                        ->where("time > $start_time AND time < $end_time")
                        ->where('type = 2')
                        ->where("g_id = $g_id")
                        ->find();
                    $recData_clik['num'] = $result_clik;
                    $list[1] = $recData_clik;
                }

                $this->assign('data', $data);
                $this->assign('list', $list);
                $this->assign('page', '');
                return view('index');
            } else {
                return $this->error('广告ID不存在');
            }

        }
    }

    public function plan(){

        $data = array(
            'module_name' => '广告',
            'module_url'  => SITE_URL.'/admin/guanggao/',
            'module_slug' => 'guanggao',
            'upload_path' => UPLOAD_PATH,
            'upload_url'  => '/public/uploads/',
        );
//       $list =   DB::table('record')->order('time desc')
//            ->paginate(10);




        $result_show = Db::table('record')
            ->where('type = 1')
            ->count("num");
        $recData_show = Db::table('record')
            ->where('type = 1')
            ->find();
        $recData_show['num'] = $result_show;
        //展示总次数
        $result_clik = Db::table('record')
            ->where('type = 2')
            ->count("num");
        $list[0] = $recData_show;
        if ($result_clik) {
            $recData_clik = Db::table('record')
                ->where('type = 2')
                ->find();
            $recData_clik['num'] = $result_clik;
            $list[1] = $recData_clik;
        }



        $this->assign('list',$list);
        $this->assign('data',$data);
        return view("Record/plan");
    }

}