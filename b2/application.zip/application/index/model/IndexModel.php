<?php
namespace app\index\model;

use think\Model;
use think\Db;
class IndexModel extends Model
{
    // 设置完整的数据表（包含前缀）
    protected $table = 'admin';

    static function getG_info($g_id)
    {
        $data = Db::table('guanggao')
            ->join('plan','plan.plan_id = guanggao.plan_id')
            //获取字段，待添加广告链接 g_lianji
            ->field('guanggao.plan_id,g_type,g_lianjie_I,g_lianjie_A,show_number,g_name')
            ->where('guanggao.g_id ='."$g_id")
            ->find();
          return $data;
    }

    static function getR_info($ip,$g_id)
    {
        $reData = Db::table('record')
            ->where('userip',$ip)
            ->where('g_id',$g_id)
            ->order('id','desc')
            ->find();
          return $reData;
    }
    static function setRecord($ip,$g_id,$time,$num,$plan_id,$planname,$g_name,$shownum)
    {
//        Db::table('record')
//            ->where('userip',$ip)
//            ->where('g_id',$g_id)
//            ->update(['time'=>$time]);

//        Db::table('record')
//            ->where('userip',$ip)
//            ->where('g_id',$g_id)
//            ->setInc('num');

        Db::table('record')
            ->insert(
                [
                    'userip'=>$ip,
                    'plan_id'=>$plan_id,
                    'g_id'=>$g_id,
                    'num'=>$num+1,
                    'time'=>$time,
                    'planname'=>$planname,
                    'g_name'=>$g_name,
                    'shownumber'=>$shownum
                ]);
    }

}