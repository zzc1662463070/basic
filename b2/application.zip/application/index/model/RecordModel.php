<?php
namespace app\index\model;

use think\Model;

class RecordModel extends Model
{
    // 设置完整的数据表（包含前缀）
    protected $table = 'record';

//    public function se
}